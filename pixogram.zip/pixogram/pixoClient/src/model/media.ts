
export class Media {
    id: number;
    userId: number;
    url: String;
    likeCount: number;
    unlikeCount: number;
    commentCount: number;
    title: String;
    description: String;
    tags: String
}